import os
import re

import jieba
import numpy as np
import pandas as pd
import pdfplumber
from gensim import models, corpora
from joblib import dump, load


model = load('./model/my-model.joblib')

pdf_directory = './test/'
output_directory = './test_data/'  # 输出文件夹

# 创建输出文件夹（如果不存在）
os.makedirs(output_directory, exist_ok=True)
# 遍历指定目录下的PDF文件
for filename in os.listdir(pdf_directory):
    if filename.endswith('.pdf'):
        pdf_filepath = os.path.join(pdf_directory, filename)
        output_filepath = os.path.join(output_directory, os.path.splitext(filename)[0] + '.txt')  # 生成对应的.txt文件名

        # 提取PDF文件内容并清洗
        with pdfplumber.open(pdf_filepath) as pdf:
            text = ""
            for page in pdf.pages:
                text += page.extract_text()

    # 使用jieba进行分词
    seg_list = jieba.cut(text, cut_all=False)
    cleaned_text = " ".join(seg_list)

    # 去除特殊字符和标点符号
    cleaned_text = re.sub(r'[^\u4e00-\u9fa5a-zA-Z0-9\s]', '', cleaned_text)

    # 转换文本为小写
    cleaned_text = cleaned_text.lower()

    stop_words = ["的", "了", "是", "我", "你",'在']  # 自定义停用词列表
    words = cleaned_text.split()
    filtered_text = [word for word in words if word not in stop_words]

    cleaned_text = ' '.join(filtered_text)

    # 将清洗后的文本保存为.txt文件
    with open(output_filepath, 'w', encoding='utf-8') as txt_file:
        txt_file.write(cleaned_text)

    print(f'已处理文件: {pdf_filepath}，并保存为: {output_filepath}')


txt_directory = './test_data/'
texts = []
for filename in os.listdir(txt_directory):
    file_path = os.path.join(txt_directory, filename)
    with open(file_path, 'r', encoding='utf-8') as file:
        text = file.read()
        texts.append(text)



# 创建词典
dictionary = corpora.Dictionary([text.split() for text in texts])

# 创建文档-词汇矩阵
corpus = [dictionary.doc2bow(text.split()) for text in texts]



# 运行LDA模型
num_topics = 10
lda_model = models.LdaModel(corpus, num_topics=num_topics, id2word=dictionary)

# 查看每个主题的词汇分布
topics = lda_model.show_topics(num_topics=num_topics, num_words=10)

# 查看每个文档的主题分布
topic_distributions = [lda_model[doc] for doc in corpus]
print(topic_distributions)
print(len(topic_distributions))
# 创建一个初始的十列数组（全零）
num_topics = 10
num_documents = len(topic_distributions)
array = np.zeros((num_documents, num_topics))

# 将主题分布的值填充到数组中
for i, doc_topics in enumerate(topic_distributions):
    for topic_id, weight in doc_topics:
        array[i, topic_id] = weight


X_test = array
y_pred = model.predict(X_test)
file = []
for filename in os.listdir(pdf_directory):
    if filename.endswith('.pdf'):
        file.append(filename)
y = {
    "filename": file,
    "label": y_pred
}
y = pd.DataFrame(y)
y.to_csv('./output/result.csv', index=False, encoding='utf-8')